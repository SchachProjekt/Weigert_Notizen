package com.example.notitzen;

import java.io.Serializable;

public class Note implements Serializable {

    String date;
    String name;
    String note;
    boolean isfinished;

    public Note(String date, String name, String note, boolean isfinished) {
        this.date = date;
        this.name = name;
        this.note = note;
        this.isfinished = isfinished;
    }

    public Note(String date, String name, String note)
    {
        this.date = date;
        this.name = name;
        this.note = note;
    }

    public String getNoteAsString(Note note)
    {
        return note.toString();
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getNoteStringLimited()
    {
        return this.date + " | " + this.name;
    }

    @Override
    public String toString()
    {
        return this.date + "-" + this.name + "-" + this.note + "-" + this.isfinished;
    }
}
