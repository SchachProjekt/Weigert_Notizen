package com.example.notitzen;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class NoteAdapter extends BaseAdapter {
    List<Note> notes;
    int layoutId;
    LayoutInflater inflater;
    private Object TextView;

    public NoteAdapter(Context ctx, int layoutId, List<Note> notes)
    {
        this.notes = notes;
        this.layoutId = layoutId;
        this.inflater = (LayoutInflater) ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return notes.size();
    }

    @Override
    public Object getItem(int i) {
        return notes.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        Note note = notes.get(i);
        LocalDate currentDate = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
        String notedate = note.getDate();

        LocalDate notedateAsLocalDate = LocalDate.parse(notedate, formatter);
        View listItem = (view == null) ? inflater.inflate(this.layoutId, null) : view;
        ((TextView) listItem.findViewById(R.id.textView)).setText(note.getNoteStringLimited());
        ((CheckBox) listItem.findViewById(R.id.checkBox)).setChecked(note.isfinished);
        if(note.isfinished){
            listItem.setBackgroundResource(R.color.green);
        }
        else if(notedateAsLocalDate.isBefore(currentDate))
        {
            System.out.println("farbe geändert");
            listItem.setBackgroundResource(R.color.Orange);
        }
        else
        {
            listItem.setBackgroundColor(Color.BLACK);
        }

        return listItem;
    }
}
