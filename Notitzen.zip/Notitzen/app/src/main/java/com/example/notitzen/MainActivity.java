package com.example.notitzen;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    String filename = "notesV3.txt";
    CheckBox checkBox;

    static ListView notesListView;
    private static List<Note> notes = new ArrayList<>();
    private static NoteAdapter mAdapter;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        configActionBar();

        checkBox = findViewById(R.id.checkBox);
        notesListView = findViewById(R.id.noteListView);

        notesListView = findViewById(R.id.noteListView);
        mAdapter = new NoteAdapter(this, R.layout.my_list_view_item_layout, notes);
        notesListView.setAdapter(mAdapter);
        readFile();
        registerForContextMenu(notesListView);

    }


    @Override
    public boolean onContextItemSelected(MenuItem item) {

        AdapterView.AdapterContextMenuInfo info =
                (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int listpostition = info.position;

        if (item. getItemId () == R.id.context_show) {

            System.out.println("deteils anzeigen");

            String name = "";
            if ( info != null ) {
                long id = info. id ;
                int pos = info. position ;
                name = info != null ?
                        notesListView .getAdapter().getItem(pos). toString () : "";
            }

            Intent intent = new Intent(this,
                    DetailActivity.class);
            intent.putExtra("note", notes.get(listpostition));
            startActivity(intent);
            return true;
        }
        if (item. getItemId () == R.id.context_delete ) {
            System.out.println("löschen");
            notes.remove(listpostition);
            updateNotesList();
            return true;
        }

        if(item.getItemId() == R.id.context_bearbeiten)
        {
            System.out.println("bearbeiten");
            Intent intent = new Intent(this, BearbeitenActivity.class);
            intent.putExtra("date", notes.get(listpostition).getDate());
            intent.putExtra("name", notes.get(listpostition).getName());
            intent.putExtra("note", notes.get(listpostition).getNote());
            startActivity(intent);
            notes.remove(listpostition);
            updateNotesList();
            return true;
        }
        return super.onContextItemSelected(item);
    }

    //TODO
    public void showPopupMenu(View view)
    {
        PopupMenu menu = new PopupMenu(this, view);
        menu.inflate(R.menu.context_menu);
        menu.setOnMenuItemClickListener((item) ->{
            return true;
        });
        menu.show();

    }



    public void updateNotesList()
    {
        mAdapter.notifyDataSetChanged();
        bindAdapterToNotesList();
    }

    public void bindAdapterToNotesList()
    {
        mAdapter = new NoteAdapter(this, R.layout.my_list_view_item_layout, notes);
        notesListView.setAdapter(mAdapter);
    }

    private void configActionBar()
    {
        ActionBar actionBar = getSupportActionBar();
        actionBar.setSubtitle("");
        actionBar.setTitle("");

        Drawable background = ContextCompat.getDrawable(this, android.R.drawable.status_bar_item_app_background);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo
                                            menuInfo) {
        int viewId = v.getId();
        if (viewId == R.id.textView || viewId ==
                R.id.noteListView) {
            getMenuInflater().inflate(R.menu.context_menu,
                    menu);
        }
        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.actionmenu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id = item.getItemId();
        switch (id)
        {
            case R.id.speichern:
                Toast.makeText(this, "Gespeichert", Toast.LENGTH_LONG).show();
                System.out.println("gespeichert");
                writeFile();

                break;
            case R.id.neuenotiz:
                Toast.makeText(this, "Neue Notiz", Toast.LENGTH_LONG).show();
                System.out.println("neue notitz");
                final View vDialog = getLayoutInflater().inflate(R.layout.dialog_layout, null);
                new AlertDialog.Builder(this)
                        .setCancelable(false)
                        .setView(vDialog)
                        .setPositiveButton("ok",(dialogInterface, i) -> handleDialog(vDialog))
                        .setNegativeButton("Cancel", null)
                        .show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void writeFile()
    {

        try {
            FileOutputStream fos = openFileOutput(filename, MODE_PRIVATE);
            PrintWriter out = new PrintWriter(new OutputStreamWriter(fos));

            for(int i = 0; i < notes.size(); i++)
            {
                System.out.println(notes.get(i).toString());
                out.print(notes.get(i).toString());
                out.println();
            }
            out.flush();
            out.close();
        }catch (FileNotFoundException exp)
        {

        }
    }

    public void readFile()
    {
        try {
            FileInputStream fis = openFileInput(filename);
            BufferedReader in = new BufferedReader(new InputStreamReader(fis));
            String line ;
            while (( line = in. readLine ()) != null ) {
                String[] arr = line.split("-");
                String date = arr[0];
                String name = arr[1];
                String note = arr[2];
                boolean isfinished = Boolean.parseBoolean(arr[3]);

                Note newNote = new Note(date, name, note, isfinished);
                notes.add(newNote);
                mAdapter.notifyDataSetChanged();
            }
            in.close () ;
        } catch (IOException exp) {

        }

    }

    public void onCheckboxClicked(View view) {
        CheckBox box = (CheckBox) view;
        int position = notesListView.getPositionForView(box);

        notes.get(position).isfinished = box.isChecked();
        updateNotesList();
    }

    private void handleDialog(final View vDialog)
    {
        EditText dateView = vDialog.findViewById(R.id.noteDateTXT);
        String date = dateView.getText().toString();

        EditText noteNameView = vDialog.findViewById(R.id.NoteNameTXT);
        String name = noteNameView.getText().toString();

        EditText noteView = vDialog.findViewById(R.id.NoteTextTXT);
        String note = noteView.getText().toString();

        notes.add(new Note(date, name, note));

        mAdapter.notifyDataSetChanged();
    }

    public static void addNote(String date, String name, String note)
    {
        Note n = new Note(date, name, note);
        notes.add(n);
        mAdapter.notifyDataSetChanged();
    }
}