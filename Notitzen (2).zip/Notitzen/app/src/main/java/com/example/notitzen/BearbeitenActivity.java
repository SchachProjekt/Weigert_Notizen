package com.example.notitzen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class BearbeitenActivity extends AppCompatActivity {

    TextView dateView;
    TextView nameView;
    TextView noteView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bearbeiten);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        String date = bundle.getString("date");
        String name = bundle.getString("name");
        String note = bundle.getString("note");

        dateView = findViewById(R.id.editDate);
        nameView = findViewById(R.id.editName);
        noteView = findViewById(R.id.editNote);

        dateView.setText(date);
        nameView.setText(name);
        noteView.setText(note);
    }


    public void onApply(View view) {
     MainActivity.addNote(dateView.getText().toString(), nameView.getText().toString(), noteView.getText().toString());
     finish();
    }

    public void onDone(View view)
    {
        MainActivity.addNoteSetToTrue(dateView.getText().toString(), nameView.getText().toString(), noteView.getText().toString(), true);
        finish();
    }

    public void onUnDone(View view)
    {
        MainActivity.addNoteSetToTrue(dateView.getText().toString(), nameView.getText().toString(), noteView.getText().toString(), false);
        finish();
    }
}